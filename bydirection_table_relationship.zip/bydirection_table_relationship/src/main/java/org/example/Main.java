package org.example;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Configuration config = new Configuration().configure("config.xml");
        SessionFactory sessionFactory = config.buildSessionFactory();
        Session session = sessionFactory.openSession();

        Department department = new Department();
        Employee emp1 = new Employee();
        Employee emp2 = new Employee();

        department.setDname("Perches");

        emp1.setName("Anil");
        emp1.setAge(22);
        emp1.setSalary(22000);
        emp1.setDepartment(department);

        emp2.setName("Rajesh");
        emp2.setAge(25);
        emp2.setSalary(25000);
        emp2.setDepartment(department);

        ArrayList<Employee> data = new ArrayList<>();
        data.add(emp1);
        data.add(emp2);

        department.setEmployees(data);

        Transaction transaction = session.beginTransaction();
        session.save(department);
        session.save(emp1);
        session.save(emp2);

        transaction.commit();
        System.out.println("Record Inserted!.......");
    }
}
